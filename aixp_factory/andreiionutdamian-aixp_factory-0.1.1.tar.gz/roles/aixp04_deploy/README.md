# Role for installing containerized apps with systemd

> TODO: 
> - [ ] More parametrization
> - [ ] Both llm_api and ee should be configured in templates


## AiXp E2 

Variables:
- `deployed_app`
- `aixp_ee_version`
- `aixp_target_folder`
- `aixp_node_name`